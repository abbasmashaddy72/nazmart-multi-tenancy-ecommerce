<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ThemeManage\\Providers\\ThemeManageServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ThemeManage\\Providers\\ThemeManageServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);