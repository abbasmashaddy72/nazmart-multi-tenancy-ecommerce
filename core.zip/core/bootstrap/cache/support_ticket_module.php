<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\SupportTicket\\Providers\\SupportTicketServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\SupportTicket\\Providers\\SupportTicketServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);