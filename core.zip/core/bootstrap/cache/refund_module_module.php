<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\RefundModule\\Providers\\RefundModuleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\RefundModule\\Providers\\RefundModuleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);