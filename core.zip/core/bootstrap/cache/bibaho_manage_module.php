<?php return array (
  'providers' =>
  array (
    0 => 'Modules\\BibahoManage\\Providers\\TestManageServiceProvider',
  ),
  'eager' =>
  array (
    0 => 'Modules\\BibahoManage\\Providers\\TestManageServiceProvider',
  ),
  'deferred' =>
  array (
  ),
);
