<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Inventory\\Providers\\InventoryServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Inventory\\Providers\\InventoryServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);