<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ShippingModule\\Providers\\ShippingModuleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ShippingModule\\Providers\\ShippingModuleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);