<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\PluginManage\\Providers\\PluginManageServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\PluginManage\\Providers\\PluginManageServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);