<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\TaxModule\\Providers\\TaxModuleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\TaxModule\\Providers\\TaxModuleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);