<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Service\\Providers\\ServiceServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Service\\Providers\\ServiceServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);