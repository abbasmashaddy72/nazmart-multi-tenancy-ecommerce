<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\NewsLetter\\Providers\\NewsLetterServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\NewsLetter\\Providers\\NewsLetterServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);