<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Blog\\Providers\\BlogServiceProvider',
    1 => 'Modules\\Blog\\Providers\\RouteServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Blog\\Providers\\BlogServiceProvider',
    1 => 'Modules\\Blog\\Providers\\RouteServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);