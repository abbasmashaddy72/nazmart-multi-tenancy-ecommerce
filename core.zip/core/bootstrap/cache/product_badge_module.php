<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\ProductBadge\\Providers\\ProductBadgeServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\ProductBadge\\Providers\\ProductBadgeServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);