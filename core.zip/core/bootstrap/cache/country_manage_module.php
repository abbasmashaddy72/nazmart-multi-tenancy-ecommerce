<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\CountryManage\\Providers\\CountryManageServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\CountryManage\\Providers\\CountryManageServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);