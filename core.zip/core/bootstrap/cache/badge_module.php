<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Badge\\Providers\\BadgeServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Badge\\Providers\\BadgeServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);