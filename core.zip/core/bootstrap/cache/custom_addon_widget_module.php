<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\CustomAddonWidget\\Providers\\CustomAddonWidgetServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\CustomAddonWidget\\Providers\\CustomAddonWidgetServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);