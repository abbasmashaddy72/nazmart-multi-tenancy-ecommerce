<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\WidgetCustomAddon\\Providers\\WidgetCustomAddonServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\WidgetCustomAddon\\Providers\\WidgetCustomAddonServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);