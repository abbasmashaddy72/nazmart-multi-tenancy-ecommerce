<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\CouponManage\\Providers\\CouponManageServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\CouponManage\\Providers\\CouponManageServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);