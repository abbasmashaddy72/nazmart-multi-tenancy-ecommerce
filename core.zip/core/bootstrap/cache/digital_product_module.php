<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\DigitalProduct\\Providers\\DigitalProductServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\DigitalProduct\\Providers\\DigitalProductServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);