<?php

return [
    'name' => 'Attributes'
];
