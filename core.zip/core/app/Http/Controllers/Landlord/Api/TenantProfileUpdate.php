<?php

namespace App\Http\Controllers\Landlord\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class TenantProfileUpdate extends Controller
{
    //
}
