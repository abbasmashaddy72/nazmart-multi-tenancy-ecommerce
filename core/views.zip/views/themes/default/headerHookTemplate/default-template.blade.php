<div class="breadcrumb-area breadcrumb-padding-two">
    <div class="container container-one">
        <div class="row">
            <div class="col-lg-12">
                <div class="breadcrumb-contents center-text">
                    <h2 class="breadcrumb-contents-title-two fw-500">Welcome to Dynamic Theme Furnito</h2>
                </div>
            </div>
        </div>
    </div>
</div>
