<div class="copyright-area copyright-bg">
    <div class="container container-three">
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <div class="copyright-contents center-text">
                        <span>
                            © 2023 Copyright All Right Reserved by HexFashion
                        </span>
                </div>
            </div>
        </div>
    </div>
</div>
