/*
It is a sample custom js file for hooks
*/
