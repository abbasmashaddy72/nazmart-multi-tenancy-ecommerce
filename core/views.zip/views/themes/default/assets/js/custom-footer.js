alert('kaj kore');
