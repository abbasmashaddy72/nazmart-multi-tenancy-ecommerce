@include('tenant.frontend.partials.header')
@yield('content')
@include('tenant.frontend.partials.footer')
