<div class="copyright-area">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-12">
                <div class="copyright-item text-center">
                    <div class="copyright-area-inner ">
                        {!! get_footer_copyright_text(\App\Helpers\LanguageHelper::user_lang_slug()) !!}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
