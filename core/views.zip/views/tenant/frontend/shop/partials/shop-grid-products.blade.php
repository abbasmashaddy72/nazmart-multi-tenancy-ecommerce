<div class="shop-grid-contents">
    @include('tenant.frontend.shop.partials.filter-partials.shop-filters')

    <div class="grid-product-list">
        @include('tenant.frontend.shop.partials.product-partials.grid-products')
    </div>

    <div class="list-product-list">
        @include('tenant.frontend.shop.partials.product-partials.list-products')
    </div>
</div>
