<link rel="stylesheet" href="{{global_asset('assets/landlord/common/css/spectrum.min.css')}}">
