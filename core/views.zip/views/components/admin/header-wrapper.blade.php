<div class="header-wrap d-flex justify-content-between">
    <div class="left-wrapper">
        {{$left}}
    </div>
    <div class="right-wrapper d-flex align-items-center">
        {{$right ?? ''}}
    </div>
</div>
