<div class="loader-01">
    <span class="loader__icon loader__icon--one"></span>
    <span class="loader__icon loader__icon--two"></span>
    <span class="loader__icon loader__icon--three"></span>
    <span class="loader__icon loader__icon--four"></span>
</div>
