<a class="btn btn-info btn-xs mb-3 mr-1" href="{{$route}}" target="_blank">
    <i class="ti-eye"></i>
</a>
