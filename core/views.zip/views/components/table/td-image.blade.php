<td>
    <div class="img-wrap max-width-100">
        {!! render_image_markup_by_attachment_id($image, '', 'grid') !!}
    </div>
</td>
