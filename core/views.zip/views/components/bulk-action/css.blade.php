<style>
    .select-box-wrap select {
        height: 40px;
        border: none;
        position: relative;
        top: 2px;
        width: 150px;
        border: 1px solid #e2e2e2;
    }
</style>
