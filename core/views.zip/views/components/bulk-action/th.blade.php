<th class="no-sort">
    <div class="mark-all-checkbox">
        <input type="checkbox" class="all-checkbox">
    </div>
</th>