<div class="form-group">
    <label for="">{{__('Seo Title')}}</label>
    <input type="text" name="seao_title" class="form-control">
</div>

<div class="form-group">
    <label for="">{{__('Seo Description')}}</label>
    <textarea name="seo_description" class="form-control" rows="5"></textarea>
</div>

<div class="form-group">
    <label for="">{{__('Seo Site URL')}}</label>
    <input type="text" name="seo_site_url" class="form-control">
</div>

<div class="form-group">
    <label for="">{{__('Seo Canonical')}}</label>
    <input type="text" name="sep_canonical" class="form-control">
</div>

<div class="form-group">
    <label for="">{{__('Seo Property')}}</label>
    <input type="text" name="seo_property" class="form-control">
</div>

<div class="form-group">
    <label for="">{{__('Seo Title for Twitter Username')}}</label>
    <input type="text" name="seo_property" class="form-control">
</div>

<div class="form-group">
    <label for="">{{__('Seo Image')}}</label>
    <input type="text" name="seo_property" class="form-control">
</div>

