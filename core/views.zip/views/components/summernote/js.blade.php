<script src="{{global_asset('assets/landlord/common/js/summernote-lite.min.js')}}"></script>
<script>
    $('textarea.summernote').summernote({
        placeholder: "{{__('Hello stand alone ui')}}",
        tabsize: 2,
        height: 120,
        toolbar: [
            ['style', ['style']],
            ['font', ['bold', 'underline', 'clear']],
            ['color', ['color']],
            ['para', ['ul', 'ol', 'paragraph']],
            ['table', ['table']],
            ['insert', ['link', 'picture', 'video']],
            ['view', ['fullscreen','help']]
        ]
    });
</script>
