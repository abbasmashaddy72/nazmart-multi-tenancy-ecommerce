<link rel="stylesheet" href="{{global_asset('assets/landlord/common/css/summernote-lite.min.css')}}">
