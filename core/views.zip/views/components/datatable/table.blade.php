<div class="table-wrap table-responsive">
    <table class="table table-default table-striped table-bordered">
        <thead class="text-white" style="background-color: #b66dff">
            {{$th}}
        </thead>
        <tbody>
            {{$tr}}
        </tbody>
    </table>
</div>
