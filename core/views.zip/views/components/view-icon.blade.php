<a class="btn btn-info btn-xs mb-3 mr-1" target="_blank" href="{{$url}}">
    <i class="las la-eye"></i>
</a>
