<button data-bs-target="#{{$target}}" data-bs-toggle="modal" class="mb-3 mr-1 btn-sm btn btn-{{$type ?? 'primary'}} {{$extra ?? ''}}" >{{$title ?? '' }}</button>
