<a class="btn-sm mb-3 mr-1 btn btn-{{$class ?? 'primary'}} {{$extraclass ?? ''}}" data-target="#{{$target}}" data-bs-toggle="modal" >{{$slot}}</a>
