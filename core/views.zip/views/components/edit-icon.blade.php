<a class="btn btn-primary btn-xs mb-3 mr-1" href="{{$url}}">
    <i class="las la-edit"></i>
</a>
