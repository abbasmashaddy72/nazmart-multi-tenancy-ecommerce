<div class="post_type_radio">
    <h6>{{__('Post Type')}}</h6>

    <div class="form-check form-check-inline d-block">
        <input class="form-check-input post_type" type="radio" checked name="inlineRadioOptions"
               id="radio_general" value="option1">
        <i class="ti-settings"></i>
        <label class="form-check-label" for="inlineRadio1">{{__('General')}}</label>

    </div>
    <div class="form-check form-check-inline d-block">

        <input class="form-check-input post_type" type="radio" name="inlineRadioOptions"
               id="radio_video" value="option2">
        <i class="ti-video-camera"></i>
        <label class="form-check-label" for="inlineRadio2">{{__('Video')}}</label>
    </div>
</div>
