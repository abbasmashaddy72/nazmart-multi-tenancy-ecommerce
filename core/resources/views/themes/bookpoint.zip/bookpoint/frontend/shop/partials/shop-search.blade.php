<div class="shop-icon">
    <div class="sidebar-icon">
        <i class="las la-bars"></i>
    </div>
</div>
