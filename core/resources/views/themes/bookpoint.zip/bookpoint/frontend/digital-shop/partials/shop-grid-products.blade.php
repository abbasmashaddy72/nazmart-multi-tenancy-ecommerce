<div class="shop-grid-contents">
    <div class="grid-product-list">
        @include(include_theme_path('digital-shop.partials.product-partials.grid-products'))
    </div>
</div>
